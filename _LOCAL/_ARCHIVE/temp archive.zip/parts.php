<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | UV Solutions</title>
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>

		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			function goToContent(index){
				$('.cc-block .left').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block .left').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
		
	</head>
	
	<body class="inner-page">
	
		<div class="wrapper">

			<div class="header round2 shadow1">

<?php include('includes/header.php') ?>
					<div class="hero-inner">
						<img src="images/hero-parts.jpg" alt="" />
					</div>
					<h2 class="section-title">Parts and Services</h2>

				<div class="carousel-content content-pad">						

					<div class="">
					
							<h3>Maintenance & Services</h3>
							<p>To ensure the longest lifespan, which Ozonia and Innoplana products are designed for, the service department recommends service agreements, according to you individual wishes, at a fixed rate.</p>
							
							<h3>Technical Support</h3>
							<p>For any query that arises in connection with the operation of an Ozonia product, the service team offers client support by telephone, fax, e-mail or, on request, by an on-site visit as well.</p>
							<h3>Spare Parts</h3>
							<p>Ozonia provides recommended &ldquo;strategic spare parts&rdquo; and &ldquo;wear & tear parts&rdquo; in order to allow minimum down-time and maximum flexibility on site. Let us know you wishes and ideas and we will design a personalized concept for you.</p>
							<h3>Training</h3>
							<p>To ensure the clientʼs ability to operate the plant and to enable him to analyze operating situations, we offer on-site as well as training in our facility in Switzerland.</p>
							<h3>Emergency Interventions</h3>
							<p>Ozonia knows about the importance of manpower availability. We are there when you need us, so donʼt hesitate to call us.</p>
							<p><em>* Find contacts for parts and service</em></p>
						
					</div>							
	
				</div><!-- end corousel content -->				
			</div><!-- end content -->					


			
<?php include('includes/footer.php') ?>

		</div><!-- end wrapper -->
	
	</body>
</html>