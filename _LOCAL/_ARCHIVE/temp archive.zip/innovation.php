<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | UV Solutions</title>
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>

		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			function goToContent(index){
				$('.cc-block .left').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block .left').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
		
	</head>
	
	<body class="inner-page">
	
		<div class="wrapper">

			<div class="header round2 shadow1">

<?php include('includes/header.php') ?>
					<div class="hero-inner">
						<img src="images/hero-inno.jpg" alt="" />
					</div>
					<h2 class="section-title">Innovation</h2>

				<div class="carousel-content content-pad">						
						<p>Recognized globally as a leader in water and wastewater treatment, innovation is a vital component of Ozonia's expertise. Around the world, Ozonia invests heavily in research and development to bring the most innovative in ozone and UV technologies to market.</p>
						<p>The Ozonia continues this strong commitment to value creation with focused RDI programs across its organization with an emphasis on project collaboration to ensure rapid and efficient transfer of new technologies on a global basis.</p>
						
						<h4>Ozonia Triplex Ozone Vessel</h4>
						<p>By integrating operational data from a fully automated ozone generator test stand with mathematical modeling results, Ozonia researchers are able to determine an ozone generator's performance efficiency under a wide range of operating conditions such as feed gas pressure, cooling water temperature, etc. The Triplex vessel ozone test stand incorporates state of the art ozone monitoring instrumentation including a UV spectrophotometer for measuring ozone concentration and an IR-spectrophotometer for gas composition analysis.</p>
						
						<h4>OZONIA Intelligent Gap System</h4>
						<p>Ozonia's newly developed IGS dielectric technology is expected to revolutionize the industrial ozone generation field &mdash; a critical milestone as ozone is increasingly applied in advanced wastewater treatment applications for control of micropollutants such as endocrine disrupting compounds and pharmaceutical wastes. One key advantage of the IGS dielectric technology is the significant reduction in power consumption to produce the equivalent weight percent of ozone as compared to conventional designs.</p>						
	
				</div><!-- end corousel content -->				
			</div><!-- end content -->					


			
<?php include('includes/footer.php') ?>

		</div><!-- end wrapper -->
	
	</body>
</html>