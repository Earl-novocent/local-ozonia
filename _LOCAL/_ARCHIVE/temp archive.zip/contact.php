<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | Contact</title>
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>

		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			function goToContent(index){
				$('.cc-block .left').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block .left').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
	</head>


	<body class="inner-page">
		<div class="wrapper whitebg round2 shadow1">
			<?php include('includes/header.php') ?>

			<div class="hero-inner clearfix">
				<div class="hero-content">
					<img src="images/hero-contact.jpg" alt="Contact us" />
				</div>	
				<?php include('includes/solutions-nav.php') ?>
			</div>

			<div class="pagecontent clearfix">			
				<h2 class="section-title">Contact Us</h2>
				<!-- <h2>Your are in this country:</h2> -->						
				<?php //include('includes/geolocate.php'); ?>
				<div class="contact-left">
				    <div class="grid1">
				    	<h3>USA</h3>
				    	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut</p>
				    	<h3>Other</h3>
				    	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut</p>
				    </div>
				    <div class="grid2">
				    	<h3>Europe</h3>
				    	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut</p>
				    </div>
				</div>
				<div class="contact-right">							
				    <form action="">
				    	<h3>Contact Us</h3>
				    	<label for="">Name:</label><input type="text" /><br />
				    	<label for="">Title:</label><input type="text" /><br />
				    	<label for="">Company:</label><input type="text" /><br />
				    	<label for="">Email:</label><input type="text" /><br />
				    	<input type="submit" class="submit"/>
				    </form>
				</div>
			</div><!-- end corousel content -->				
		</div><!-- end content (wrapper) -->					

		<?php include('includes/footer.php') ?>
	</body>
</html>
