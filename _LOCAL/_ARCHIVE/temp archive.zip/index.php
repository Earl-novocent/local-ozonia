<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia</title>
		<script type="text/javascript" src="scripts/jquery.innerfade.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			//Slide nav setup
			$('.slide-wrap .slide').each(function(){
				$('.slide-nav').append('<li><a href="#"></a></li>');
			});
			$('.slide-nav li a').eq(0).addClass('active');
			
			//Slide nav
			var slideTotal = $('.slide-wrap .slide').length;
			var currentSlide = 0;
			var slideHeight = $('.slide-wrap').height();
					
			//Bullet nav
			var bullNum =  0;
			$('.slide-nav li a').each(function(){	
				$(this).attr({href: bullNum});
				$(this).click(function(e){
					e.preventDefault();
					$('.slide-nav li a').eq(currentSlide).removeClass('active');
					currentSlide = $(this).attr('href');
					animSlide();
					$('.slide-nav li a').eq(currentSlide).addClass('active');
				});
				bullNum++;
			});
								
			//Slide navigate Function
			function animSlide(){
				var animAmount = currentSlide * slideHeight * -1;
				$('.slide-wrap ul').animate({marginTop: animAmount},300)
			};	
			
			setInterval(function(){
				if(currentSlide < slideTotal-1){
					$('.slide-nav li a').eq(currentSlide).removeClass('active');
					currentSlide++;
					$('.slide-nav li a').eq(currentSlide).addClass('active');
					animSlide();					
				}else if(currentSlide == slideTotal-1){
					$('.slide-nav li a').eq(currentSlide).removeClass('active');
					currentSlide = 0;
					$('.slide-nav li a').eq(currentSlide).addClass('active');
					animSlide();					
				}
			}, 8000);
			
			// news ticker - innerfade
			$('.ticker').innerfade({
				animationtype: 'slide',
				speed: 750,
				timeout: 2000,
				type: 'sequence',
				containerheight: '30px'
			});
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();		
		
			//Phone number display code
			$('.phone .info').hide();
			$('.phone').eq(0).css("z-index" , "30");
			$('.phone').eq(1).css("z-index" , "20");
			$('.phone').hover(
				function(){
					$(this).children('li').children('.info').slideDown(200);					
				},
				function(){
					$(this).children('li').children('.info').slideUp(200);
				}				
			);	
			
			//Animate featured images on home page
			$('.features li').hover(
				function(){
					$(this).animate({
						top: '3px'
					}, 175, function(){}
					);
				}, 
				function(){
					$(this).animate({
						top: '0px'
					}, 175, function(){}
					);			
				}
			);
		
		});
		
		
		</script>			
	</head>
	
	<body id="home-page">
	
		<div class="wrapper whitebg round1 shadow1">
				<?php include('includes/header.php') ?>
		
			<div class="hero-hp">
				<div class="hero-content">
					<ul class="slide-nav"></ul>
					<div id="slider" class="slide-wrap">
						<ul>
							<li class="slide">
								<img src="images/slides/slide-aop.jpg" alt="slide-cfv" width="548" height="255" />
							</li>
	
							<li class="slide">
								<img src="images/slides/slide-aop2.jpg" alt="slide-cfv" width="548" height="255" />
							</li>
							<li class="slide">
								<img src="images/slides/slide-cfv.jpg" alt="slide-cfv" width="548" height="255" />
							</li>
							<li class="slide">
								<img src="images/slides/slide-ozonia.jpg" alt="slide-cfv" width="548" height="255" />
							</li>
							<li class="slide">
								<img src="images/slides/slide-safety.jpg" alt="slide-cfv" width="548" height="255" />
							</li>
						</ul>
					</div>
				</div>	
				
				<?php include('includes/solutions-nav.php') ?>
				
				<div class="phones">
					<ul class="phone">
						<li class="title">Sales</li>
						<li>
							<ul class="info">
								<li>Tel: +41 44 801 85 11</li>
								<li>Fax: +41 44 801 85 02</li>
								<li><a href="mailto:info-ozoniaCH@degtec.com">Email Sales</a></li>
							</ul>	
						</li>				
					</ul>
					<ul class="phone">
						<li class="title">Customer Care</li>
						<li>
							<ul class="info">
								<li>Tel: +41 44 801 86 63</li>
								<li>Fax: +41 44 801 85 02</li>
								<li><a href="mailto:service-ozoniach@degtec.com">Email Customer Service</a></li>
							</ul>
						</li>					
					</ul>
				</div>
			
			</div>
		
		
		</div>

		<div class="wrapper news">
			<h5 class="ticker-h5">Latest <span class="red">&raquo;</span></h5>
		    <ul class="ticker round2">
		    	<li><a href="#">News Ticker Item</a></li>
		    	<li><a href="#">News Ticker 2</a></li>
		    	<li><a href="#">News Ticker 3</a></li>
		    	<li><a href="#">News Ticker 4</a></li>
		    	<li><a href="#">News Ticker 5</a></li>
		    </ul>
		</div>
		
		<ul class="wrapper features">
		    <li><a href="ozone.php#0"><img src="images/features/OZONE.png" alt="OZONE" width="182" height="146" /></a></li>
		    <li><a href="uv.php#0"><img src="images/features/UV.png" alt="UV" width="182" height="146" /></a></li>
		    <li><a href="aop.php"><img src="images/features/AOP.png" alt="AOP" width="182" height="146" /></a></li>
		    <li><a href="app.php#0"><img src="images/features/APPLICATIONS.png" alt="APPLICATIONS" width="182" height="146" /></a></li>
		    <li><a href="parts.php"><img src="images/features/SERVICE.png" alt="SERVICE" width="182" height="146" /></a></li>
		</ul>
			
		<?php include('includes/footer.php') ?>

	
	</body>
</html>