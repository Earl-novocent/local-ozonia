<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia</title>
		<script type="text/javascript" src="scripts/jquery.roundaboutv2.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			$('.carousel ul').roundabout({
				//debug: true,
				reflect:true,
				shape: 'square',
				minScale: .4,
				btnPrev: '#carPrev',
				btnNext: '#carNext',
				btnNextCallback: function(){showContent('next')},
				btnPrevCallback: function(){showContent('prev')}
			});
			
			//set defaults
			$('#carPrev, #carNext').click(function(e){
				e.preventDefault();
			});								
			
			//$('.cc-block').not(':first-child').hide();
			$('.cc-block').hide();
			
			// Get total sections
			var sectionTotal = 0;
			$('.carousel li a').each(function(index){
				sectionTotal++;
				$(this).click(function(){
					goToContent(index);
				});		
			});
						
			//Track current section
			var curSection = 0;			
			
			//Show content based on NextPrev buttons or solutions nav
					
			function showContent(nextOrPrev){				
					$('.cc-block').eq(curSection).fadeOut(300, function(){					
						if(nextOrPrev == 'next'){
							if(curSection < sectionTotal-1){
								curSection++;							
								$('.cc-block').eq(curSection).fadeIn();
							}else{
								curSection = 0;	
								$('.cc-block').eq(curSection).fadeIn();
							}
						}
						else if(nextOrPrev == 'prev'){
							if(curSection > 0){
								curSection--;						
								$('.cc-block').eq(curSection).fadeIn();	
							}else{						
								curSection = sectionTotal-1;													
								$('.cc-block').eq(curSection).fadeIn();	
							}
	
						}
	
					});
			};				
			
			function goToContent(index){
				$('.cc-block').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block').eq(curSection).fadeIn();	
				});
			};
			
			// Navigate to content section when click on carousel images
			$('.carousel ul li a').click(function(e){
					e.preventDefault();
					thisIndex = $('.carousel ul li a').index(this);
					goToContent(thisIndex);
			});	
						
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					//$('.carousel ul').roundabout_animateToChild(hash);					
					$('.carousel ul').roundabout('animateToChild',hash);			
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
		
	</head>
	
	<body class="inner-page">
		<div class="wrapper whitebg sround2 shadow1">
			<?php include('includes/header.php') ?>

			<div class="hero-inner clearfix">
				<div class="hero-content">

					<div class="carousel">
						<ul>
							<li><a href=""><img src="images/carousel/apps/aquaculture.jpg" alt="aquaculture" /></a></li>
							<li><a href=""><img src="images/carousel/apps/beverage.jpg" alt="beverage" /></a></li>
							<li><a href=""><img src="images/carousel/apps/coolingtowers.jpg" alt="cooling towers" /></a></li>
							<li><a href=""><img src="images/carousel/apps/disinfection.jpg" alt="disinfection" /></a></li>
							<li><a href=""><img src="images/carousel/apps/food.png" alt="food" /></a></li>
							<li><a href=""><img src="images/carousel/apps/processwater.jpg" alt="process water" /></a></li>
							<li><a href=""><img src="images/carousel/apps/ultrapure.jpg" alt="ultrapure water" /></a></li>
							<li><a href=""><img src="images/carousel/apps/aquariums.jpg" alt="aquariums" /></a></li>
							<li><a href=""><img src="images/carousel/apps/colorremoval.jpg" alt="color removal" /></a></li>
							<li><a href=""><img src="images/carousel/apps/cyanideregeneration.jpg" alt="cyanide regeneration" /></a></li>
							<li><a href=""><img src="images/carousel/apps/drinkingwater.jpg" alt="drinking water" /></a></li>
							<li><a href=""><img src="images/carousel/apps/industrialeffluent.jpg" alt="industrial effluent" /></a></li>
							<li><a href=""><img src="images/carousel/apps/swimmingpools.jpg" alt="swimming pools" /></a></li>
						</ul>
					</div>
					<ul class="carousel-nav">
						<li><a href="#" id="carPrev">&laquo;</a></li>
						<li class="last"><a href="#" id="carNext">&raquo;</a></li>
					</ul>

				</div>	
				<?php include('includes/solutions-nav.php') ?>
			</div>

			<div class="pagecontent">			

				<h2 class="section-title">Applications</h2>

				<div class="carousel-content clearfix">

					<div class="cc-block">
						<div class="left">
							<h3>Aquaculture</h3>
							<h4>(Fish Farming and Hatcheries)</h4>
							<p>Ozone and/or Ultra Violet (UV) disinfection can play important roles in the prevention and elimination of fish diseases in aquaculture systems. Ozone, a powerful oxidizing agent disinfects and oxidizes organic pollutants while increasing the water?s dissolved oxygen level. The end result is exceptional water quality, which is a fundamental requirement for intensive fish farming.</p>
							<p>Ultra Violet light systems economically disinfect make-up water in both fresh and saltwater farms without additional chemicals or bromate formation.Both ozone and UV systems are easy to adapt to large scale ponds and raceways as well as small holding tanks and nurseries. Improved water quality leads to reduced mortality rates and an increased yield of a healthier product. Other benefits include a reduction of chemical additives for water treatment or vaccines and antibiotics. Ozonia has extensive experience in the aquaculture industry with numerous hatchery and fish farming installations worldwide. Let us show you how our ozone</p>										</div>
						<div class="right">
							<h4>Associated Products</h4>
							<ul>
								<li><a href="ozone.php#0">Ozone</a></li>
								<li><a href="uv.php#0">UV</a></li>	
							</ul>
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing pdf -->
								<li><a href="media/pdf/">Download Our Fish Hatcheries White Paper [in English]</a></li>
								<!-- missing pdf -->
								<li><a href="media/pdf/">Download Our Fish Hatcheries White Paper [in German]</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->					
					
					<div class="cc-block">
						<div class="left">
						<h3>Beverage and Water Bottling</h3>
						<p>Over the last decade there has been an increased demand for bottled water and other beverages. This demand has drawn manufacturers attention to the need for specialized filling techniques, proper sanitation practices and enhanced water disinfection and bottle sterilization. Most bottling companies rely on the use of ozone to meet these ever increasing legislative and consumer quality demands.</p>
						<p>There are three main applications for ozone in the bottling industry including the ozonation of the wash water used to clean the bottles prior to filling, ozonation of the actual bottling water and ozone for Clean In Place (CIP) system sanitation. Experience has indicated that a small dose of ozone from a high concentration ozone monitor in the region of 0.3 mg/l to 0.5 mg/l is sufficient to sanitize the product and the product packaging.</p>
						<p>Regardless of the application point of ozone, the final bottled product will be dramatically improved with consumer safety and confidence increased.</p>					
						</div>
						<div class="right">
							<h4>Associated Products</h4>
							<ul>
								<li><a href="ozone.php#8">OZFIL</a></li>									
							</ul>
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing pdf -->
								<li><a href="media/pdf/">Ozone for Water Bottling Applications</a></li>

							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Cooling Towers</h3>
							<p>Ozone has been proven a valuable tool as a biocide for the treatment of industrial and utility cooling water systems. When properly applied an improvement in operational efficiency due to increased heat transfer can be expected. Additional benefits include improved environmental impact by reduced chemical blow-down and an overall reduction in on-going chemical costs. Reduced system corrosion when attributed to chemical biocides is also possible.</p>
							<p>Ozonia works with a number of experienced OEMʼs who would be happy to discuss your cooling water applications.</p>			
						</div>
						<div class="right">
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing links -->
								<li><a href="media/pdf/">Cooling Towers</a></li>
								<li><a href="media/pdf/">Cooling Tower Case Study</a></li>
								<li><a href="media/pdf/">Ozone as a disinfecting agent</a></li>
								<li><a href="media/pdf/">Cooling Water Case Study</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Disinfection</h3>
							<p>In recent years there has been an increased focus on food safety and in particular the methods used to reduce and eliminate pathogens from fresh produce. With the rise in consumption of fresh fruits and vegetables, incidents of food-borne illness have also greatly increased in the US, drawing significant attention from researchers and authorities. Traditional methods revolve around the use of chemicals such as chlorine in the sanitizing of produce, specifically in rinsing and washing. Chlorine is widely used in these processes but it has a limited effect in killing bacteria on fruit and vegetables surfaces. There is also wide concern with regards to the by-products of chlorine and its effects on health and the environment.</p>
							
							<p>Ozone is becoming a popular alternative solution to traditional sanitizing agents and providing additional benefits. Ozone as an oxidizing agent, 1.5 times more powerful than chlorine and effective over a much wider spectrum of microorganisms. Ozone kills viruses and bacteria such as Escherichia coli and Listeria much faster than chlorine and other chemical agents and is free of chemical residues as it decomposes into simple oxygen.</p>
							
							<p>Ozone can effectively be used in several applications in the food and packing industries including the disinfection of process water, poultry chill water treatment, produce washing and rinsing, process water recycling and produce storage.</p>		
						</div>
						<div class="right">
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing links -->
								<li><a href="media/pdf/">BOC's ozone technology centerpiece of Fresh Mark's pathogen reduction program</a></li>
								<li><a href="media/pdf/">Ozone for bottling applications</a></li>
								<li><a href="media/pdf/">U.S. FDA Regulatory Approval of Ozone as an Antimicrobial Agent</a></li>
								<li>The use of ozone as a disinfectant in fish hatcheries and fish farms [<a href="">English</a> | <a href="">German</a>]</li>
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Food / Produce / Poultry</h3>
							
							<p>In recent years there has been an increased focus on food safety and in particular the methods used to reduce and eliminate pathogens from fresh produce. With the rise in consumption of fresh fruits and vegetables, incidents of food-borne illness have also greatly increased in the US, drawing significant attention from researchers and authorities. Traditional methods revolve around the use of chemicals such as chlorine in the sanitizing of produce, specifically in rinsing and washing. Chlorine is widely used in these processes but it has a limited effect in killing bacteria on fruit and vegetables surfaces. There is also wide concern with regards to the by-products of  chlorine and its effects on health and the environment.</p>
							
							<p>Ozone is becoming a popular alternative solution to traditional sanitizing agents and providing additional benefits. Ozone as an oxidizing agent, 1.5 times more powerful than chlorine and effective over a much wider spectrum of microorganisms. Ozone kills viruses and bacteria such as Escherichia coli and Listeria much faster than chlorine and other chemical agents and is free of chemical residues as it decomposes into simple oxygen.</p> 
							
							<p>Ozone can effectively be used in several applications in the food and packing industries including the disinfection of process water,  poultry chill water treatment, produce washing and rinsing, process water recycling and produce storage.</p>			
						</div>
						<div class="right">
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing links -->
								<li><a href="" />BOC's ozone technology centerpiece of Fresh Mark's pathogen reduction program</a></li>
								<li><a href="" />Ozone for bottling applications</a></li>
								<li><a href="" />U.S. FDA Regulatory Approval of Ozone as an Antimicrobial Agent</a></li>
								<li>The use of ozone as a disinfectant in fish hatcheries and fish farms [<a href="">English</a> | <a href="">German</a>]</li>
								<li><a href="" />Certification of ozone in usa food industries</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->					
					
					<div class="cc-block">
						<div class="left">
							<h3>Process Water</h3>
							<p>The term "process water" covers all types of industrial water applications from recirculated wash water in car washes right through the spectrum to foodstuffs rinsing,steep-water in maltings, cooling water make-up, etc. In each case the addition of ozone will achieve a certain result to improve the process be it simple disinfection or the reduction of an unwanted component.</p>		
						</div>
						<div class="right">
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing links -->
								<li><a href="">AOX and COD removal from landfill leachates with ozone and radical reactions	</a></li>
								<li><a href="">BOC's ozone technology centerpiece of Fresh Mark's pathogen reduction program</a></li>
								<li><a href="">By-product formation during uv disinfection of a pre-treated surface water</a></li>
								<li><a href="">Ozonation and granular activated carbon filtration</a></li>
								<li><a href="">Certification of ozone in usa food industries</a></li>
								<li><a href="">Concentrated oxygen - ozone mixtures stabiility at high pressure</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Ultrapure Water</h3>
							<p>Ozone and UV are the most widely accepted and recognized methods for disinfection of ultra-pure water (UPW). Most commonly used in the pharmaceutical, semiconductor,cosmetics and beverage industries, UPW systems treated with Ozonia ozone and UV systems routinely achieve microbial counts below 1 cfu / 100 ml. Ozone has proven itself the most reliable technique for clean-in-place (CIP) applications where minimum down-time to remove bio-burden is required.</p>
							
							<p>With several hundred ozone and UV installations installed and operating on UPW systems, Ozonia is the recognized world leader for ultra-water sanitization. Ozonia MEMBREL® Electrolytic Ozone Systems disinfect in-situ offering the added benefits of simplicity to a complicated process. In combination with Ozonia Medium Pressure UV,ozone removal, TOC reduction and product safety are assured.</p>		
						</div>
						<div class="right">
							<h4>Additional Reading</h4>
							<ul>
								<!-- missing links -->
								<li><a href="">Ozone as a disinfecting agent in the reuse of wastewater</a></li>
								<li><a href="">Electrolytic ozone generation and its application in pure water systems</a></li>								
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Aquariums (Zoos)</h3>
							<p>Large municipal aquariums and zoos disinfect water with ozone to protect the different species in their care from infection due to water borne virus and disease. Because ozone is easy to control without a long-lasting residual, the animals are also protected from irritation around sensitive areas often associated with chemical disinfectants. Large aquariums also use ozone to improve the water clarity for maximum impact on the viewing public.</p> 
							
							<p>Ozonia has designed and supplied systems to treat water flow rates from as little as 6 gallons per minute (1.3 m3/h) to entire municipal aquariums with an assortment of fish, mammals and reptiles. Let us show you how our ozone or UV products can economically improve the water quality at your exhibits and features.</p> 
						</div>
						<div class="right">

						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Color Removal</h3>
							<p>Color due to organic molecules or products break down quickly when they come into contact with ozone. The powerful oxidation potential of ozone has made color removal one of the "classic" ozone applications for dri king water along with taste and odor removal which are also organic based. This need has crossed over to wastewater treatment (industrial and municipal) and today ozone is used extensively to remove color from effluents from dye manufacturers, textile mills, pharmaceutical factories and other industrial companies.</p>
							
							
							<p>Ozone is also used extensively as a "bleach" in many processes such pulp and paper manufacturing, kaolin production and even textiles (stone washed denim). Ozonia has a broad range of products from laboratory scale ozonators to large engineered ozone plants to satisfy any possible color removal need.</p>
						</div>
						<div class="right">

						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Cyanide Regeneration</h3>
							<p>Cyanide processes used for the extraction of gold and silver from mineral ores frequently generate thiocyanide due to the processing of sulphur containing solids. Ozone can be utilized to recover cyanide from thiocyanate for less than the cost of newly purchased cyanide. Net benefits include reduced chemical consumption and handling, safety and lower operating costs.</p>
						</div>
						<div class="right">
							<h4>Additional reading:</h4>
							<ul>
								<!-- missing links -->
								<li><a href="">AOX and COD removal from landfill leachates with ozone and radical reactions</a></li>
								<li><a href="">By-product formation during uv disinfection of a pre-treated surface water  </a></li>
								<li><a href="">Ozonation and granular activated carbon filtration</a></li>							
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Drinking Water</h3>
							<p>Both Ozone and UV are well recognized methods for municipal drinking water treatment and disinfection. Each can be used for the inactivation of viruses, giardia, cryptospordium, bacteria and other microbial contaminants. While UV is limited to</p>
							<p>disinfection, ozone is also an effective treatment for taste, odor and color removal, iron and manganese reduction, as well as being a flocculating agent. Ozone and/or UV require a relatively short residence times for disinfection unlike chemicals such as chlorine and chlorine derivatives.</p>

						</div>
						<div class="right">
							<h4>Associated Products:</h4>
							<ul>
								<!-- missing links -->
									<li><a href="">All Ozone Products</a></li>
									<li><a href="">All UV Products</a></li>
					
							</ul>
							<h4>Additional reading:</h4>
							<ul>
								<!-- missing links -->
									<li><a href="">Ozone in the Advancement of Drinking Water Treatment Technology</a></li>
									<li><a href="">AOX and COD removal from landfill leachates with ozone and radical reactions</a></li>
									<li><a href="">BOC's ozone technology centerpiece of Fresh Mark's pathogen reduction program</a></li>
									<li><a href="">Study on By-Products of Ozonation during Ammonia Removal under the Existence of Bromide</a></li>
									<li><a href="">Ozonation and granular activated carbon filtration</a></li>
									<li><a href="">Ozone as a disinfecting agent in the reuse of wastewater</a></li>						
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Industrial Effluent</h3>
							<p>Effluent wastewater from an industrial facility may carry a broad and variable range of contaminants, including BOD, COD, color, phenols, cyanides, sanitary waste and a host of complex chemicals. Ozone, in combination with UV and/or other physical, chemical or biological processes, has the potential to treat complex industrial wastes due to its strong oxidative nature. In combination with medium pressure UV, ozone exhibits the power of advanced oxidation for TOC reduction, as well as destruction of organics. Potential industries that can benefit from ozone and UV include  pharmaceuticals, textiles, automotive, foundry, etc.</p>

						</div>
						<div class="right">
							<h4>Additional reading:</h4>
							<ul>
								<!-- missing links -->
								<li><a href="">AOX and COD removal from landfill leachates with ozone and radical reactions</a></li>
								<li><a href="">BOC's ozone technology centerpiece of Fresh Mark's pathogen reduction program</a></li>
								<li><a href="">Landfill leachate treatment: case studies</a></li>
								<li><a href="">Pilot plant investigation of ozone disinfection of physicochemically treated municipal wastewater</a></li>
								<li><a href="">Ozonation and granular activated carbon filtration</a></li>					
							</ul>
						</div>
					</div><!-- end cc block -->
					
					<div class="cc-block">
						<div class="left">
							<h3>Swimming Pools</h3>
							<p>Ozone and UV are very effective alternatives to chlorine and other chemicals as a disinfection agent in swimming pools. Ozone and UV can safely prevent the formation of chlorine byproducts, such as chloramines and trihalomethanes. Ozone and UV can breakdown chlorinated byproducts, therefore reducing the typical problems associated with pools such as red eyes and respiration ailments. Ozone will also oxidize oils and other contaminants in swimming pools and spa water into safer elements. The use of ozone and UV can play an essential role in providing a clean and pleasant environment for bathers and pool staff.</p>
						</div>
						<div class="right">
							&nbsp;
						</div>
					</div><!-- end cc block -->
				</div><!-- end corousel content -->							


			</div><!-- end pagecontent -->				
		</div><!-- end content (wrapper) -->					

		<?php include('includes/footer.php') ?>
	</body>