$(document).ready(function() {
	$('.nav li:last a').css('border', 'none');
	$('.features li:last').css('margin-right', '0px');
	$('.phone').eq(0).css('margin-bottom', '10px');
	$('.carousel').css('margin-top', '30px');
	$('#slider').css('background', 'none');


});