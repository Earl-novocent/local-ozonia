$(document).ready(function() {
			$('.solution-list select').easySelectBox({speed: 100});
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {
					//window.location.replace($(this).attr('rel'));
					window.open($(this).attr('rel'), '_self');
					window.location.reload();
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();		
			
			function goToContent(index){
				$('.cc-block').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block').eq(curSection).fadeIn();	
				});
			};		
});