<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | About</title>
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>

		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			function goToContent(index){
				$('.cc-block .left').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block .left').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
		
	</head>
	
	<body class="inner-page">
	
		<div class="wrapper">

			<div class="header round2 shadow1">

<?php include('includes/header.php') ?>
					<div class="hero-inner">
						<img src="images/hero-about.jpg" alt="" />
					</div>
					<h2 class="section-title">About Ozonia</h2>

				<div class="carousel-content">						

					<div class="cc-block">

						<p>With a global presence, Ozonia is regarded as the world leader specializing in ozone generation and ultraviolet (UV) technology for industrial and municipal water treatment.</p>
						<p>Ozonia is one of the worldʼs largest leading suppliers of UV and ozone disinfection systems. Ozonia has a long history and extensive experience in both technologies, and supplies ozone and UV equipment to the municipal and industrial sectors. As disinfection of water and wastewater is a global need, Ozonia has representatives in many countries worldwide, each of which use the same core technologies to provide global customers the proper support services.</p>
						<p>As a leader in disinfection solutions, Ozonia designs and manufactures a wide range of though ozone and UV technologies incorporating the most sophisticated electronics technology available. Ozonia systems are designed for various water and wastewater treatment application in the municipal and industrial markets. Each system has a variety of technical features developed to simplify installation and allow minimal operator attention and maintenance.</p>

					</div><!-- end cc block -->							
	
				</div><!-- end corousel content -->				
			</div><!-- end content -->					


			
<?php include('includes/footer.php') ?>

		</div><!-- end wrapper -->
	
	</body>
</html>