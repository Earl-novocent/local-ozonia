		<link rel="stylesheet" type="text/css" href="css/styles.css" />
		<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
		<script type="text/javascript" src="scripts/easyselectbox.min.js"></script>
		<script type="text/javascript" src="scripts/common.js"></script>	
		<script type="text/javascript" src="scripts/jquery.url.js"></script>				
		<!--[if lt IE 8]>
			<link rel="stylesheet" href="css/ie.css" />
			<script type="text/javascript" src="scripts/ie-fix.js"></script>
		<![endif]-->
		