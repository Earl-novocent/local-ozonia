			<div class="footer">
				<h3 class="footer-logo">Ozonia</h3>
				<div class="footer-nav-wrap">
					<ul class="footer-nav">
						<h6>TECHNOLOGY:</h6>
						<li><a href="ozone.php#0">Ozone</a></li>
						<li><a href="uv.php#0">UV</a></li>
						<li><a href="aop.php">AOP</a></li>
					</ul>
					<ul class="footer-nav">
						<h6>PROCESS:</h6>
						<li><a href="app.php#0">Applications</a></li>
						<li><a href="innovation.php">Innovations</a></li>
						<li><a href="#">Case Studies</a></li>
					</ul>
					<ul class="footer-nav">
						<h6>COMPANY:</h6>
						<li><a href="about.php">About Us</a></li>
						<li><a href="contact.php">Sale Contacts</a></li>
						<li><a href="contact.php">Service Contacts</a></li>
					</ul>
				</div><!-- end footer nav wrap -->					
				<ul class="suez-links">
					<li><a href="http://www.suez-environment.com">www.suez-environment.com</a></li>
					<li><a href="http://www.degremont.com">www.degremont.com</a></li>
					<li><a href="http://www.degremon-technologies.com">www.degremon-technologies.com</a></li>
				</ul>
				<img class="suez-logo" src="images/logo-suez-footer.png" alt="logo-suez-footer" width="116" height="76" />
				<p class="copyright">&copy; 2011 OZONIA AG - All rights reserved &bull; Site design by <a href="http://novocentpartners.com">Novocent Partners</a></p>
			</div><!-- end footer -->
