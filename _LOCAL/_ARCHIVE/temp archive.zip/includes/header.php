				<h1 class="logo"><a href="index.php"><img src="images/logo.png" alt="Ozonia"/></a></h1>
				<ul class="header-links">
					<li><a href="http://www.suez-environnement.com">www.suez-environnement.com </a></li>
					<li><a href="http://www.degremont.com">www.degremont.com</a></li>
					<li><a href="http://www.degremont-technologies.com">www.degremont-technologies.com</a></li>					
				</ul>
				<form class="search-header"action="#"><input type="text" placeholder="search"/></form>
				<div class="language">
					<a href="#" class="active">EN</a>
					<a href="#">FR</a>
				</div>
				
<?php include('nav.php') ?>				
				<h2 class="logo-tag">a world leader in ozone and UV water treatment</h2>
<?php include('solutions-nav.php') ?>