				<div class="solutions">
					<h3>Find Solutions</h3>
					<ul class="solution-list">
						<form action="">
						<li>							
							<select>
								<option value="#" selected="selected">Applications</option>
								<option value="app.php#0">Aquaculture</option>
								<option value="app.php#1">Beverage and Water Bottling</option>
								<option value="app.php#2">Cooling Towers</option>
								<option value="app.php#3">Disinfection</option>
								<option value="app.php#4">Food / Produce / Poultry</option>
								<option value="app.php#5">Process Water</option>
								<option value="app.php#6">Ultrapure Water</option>
								<option value="app.php#7">Aquariums (Zoos)</option>
								<option value="app.php#8">Color Removal</option>
								<option value="app.php#9">Cyanide Regeneration</option>
								<option value="app.php#10">Drinking Water</option>
								<option value="app.php#11">Industrial Effluent</option>
								<option value="app.php#12">Swimming Pools</option>

							</select>						
						</li>
						<li>
							<select>
								<option value="#" selected="selected">Technology</option>
								<option value="ozone.php#0">Ozone</option>
								<option value="uv.php#0">UV</option>
								<option value="aop.php">AOP</option>
								<option value="ozone.php#4">IGS</option>
								<option value="ozone.php#5">Modipac</option>
							
							</select>
						</li>
						<li>
							<select>
								<option value="#" selected="selected">Literature</option>
								<option value="media/pdf/AOP-COD-US.pdf">AOP Solutions</option>
								<option value="media/pdf/US_OZONE_RANGE.pdf">Ozone Range</option>
								<option value="media/pdf/US_UV_RANGE.pdf">UV Range</option>
								<option value="media/pdf/US_OZONIA_GLOBAL.pdf">Ozonia Global Applications</option>
								<option value="media/pdf/US_OZONIA_DW.pdf">Drinking Water Treatment</option>
								<option value="media/pdf/EU_OZONIA_PROCESS_WATER.pdf">Process Water Treatment</option>
								<option value="media/pdf/EU_OZONIA_REUSE.pdf">Water Reuse</option>
								
							</select>
						</li>
						<li>
							<select>
								<option value="#" selected="selected">Case Studies</option>
								<option value="media/pdf/cs_Ozonia_CoolingWater.pdf">Cooling Water Treatment in a Thermal Power Station</option>
								<option value="media/pdf/cs_Ozonia_ElDorado.pdf">El Dorado Irrigation District, Cameron Park, CA: Aquaray HO UV Disinfection System</option>
								<option value="media/pdf/cs_Ozonia_Loftsome.pdf">Loftsome Bridge Water Treatment Works, East Yorkshire U.K.: WTW Ozone Plant</option>
								<option value="media/pdf/cs_Ozonia_Rostock.pdf">Rostock Water Works, Rostock, Germany: Drinking Water Ozone Plant</option>
								<option value="media/pdf/cs_Ozonia_Saltzgitter.pdf">Landfill Diebesstieg/Disposal Centre, Salzgitter-Diebesstieg, Germany: Landfill Leachate Ozone Treatment Plant</option>

							</select>
						</li>
						</form>
					</ul>
				</div><!-- end solutions -->