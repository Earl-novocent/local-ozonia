			<div class="nav-bar">
				<ul class="nav">
					<li><a href="ozone.php#0">Ozone</a></li>
					<li><a href="uv.php#0">UV</a></li>
					<li><a href="aop.php">AOP</a></li>
					<li><a href="app.php#0">Applications</a></li>
					<li><a href="innovation.php">Innovation</a></li>
					<li><a href="parts.php">Parts &amp; Service</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contacts</a></li>		
				</ul>
			</div><!-- end nav-bar -->