<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | UV Solutions</title>
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>

		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			function goToContent(index){
				$('.cc-block .left').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block .left').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
						console.log(relSplit[0]);
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
		
	</head>
	
	<body class="inner-page">
	
		<div class="wrapper">

			<div class="header round2 shadow1">

<?php include('includes/header.php') ?>
					<div class="hero-inner">
						<img src="images/hero-aop.jpg" alt="" />
					</div>

					<h2 class="section-title">AOP</h2>

				<div class="carousel-content content-pad">						

						<div class="cc-block">
							<div class="left">
								<h3>COMPLEX PROBLEMS REQUIRE RADICAL SOLUTIONS :</h3>
								
								<p>State-of-the-art AOP systems developed by Ozonia use or combine three proven treatment technologies (Ozone, UV, Hydrogen Peroxide) to create hydroxyl radicals, the ultimate oxidant for elimination of organic pollutants.</p>
								<p>AOP are aqueous phase oxidation methods consisting of highly reactive species used in the oxidative destruction of target pollutants. AOP creates a more powerful and less selective secondary oxidant, hydroxyl radicals, in the water. This secondary oxidant can cause the oxidation of most organic compounds until they are fully mineralized as carbon dioxide and water. The hydroxyl radical has a much higher oxidation potential than ozone or hydrogen peroxide and usually reacts at least one million times faster, thus leading to a smaller contact time and footprint.</p>
							
								<img src="images/aop-graphic.jpg" alt="AOP process" />
							</div>
							<div class="right">
										<h4>Product Range:</h4>
										<ul>
											<li><a href="media/pdf/AOP-COD-US.pdf">Ozonia - AOP Solutions (U.S.) PDF - 910.7 kb</a></li>
											<li><a href="media/pdf/AOP-COD-A4.pdf">Ozonia - AOP Solutions (A4) PDF - 254.2 kb</a></li>
											<li><a href="media/pdf/AOP-Datasheet-US.pdf">Ozonia - AOP Datasheet (U.S.) PDF - 597.1 kb</a></li>
											<li><a href="media/pdf/AOP-Datasheet-A4.pdf">Ozonia - AOP Datasheet (A4) PDF - 200.9 kb</a></li>
										</ul>
										
							</div><!-- end right -->
						</div><!-- end cc block -->						
						
	
				</div><!-- end corousel content -->				
			</div><!-- end content -->					


			
<?php include('includes/footer.php') ?>

		</div><!-- end wrapper -->
	
	</body>
</html>