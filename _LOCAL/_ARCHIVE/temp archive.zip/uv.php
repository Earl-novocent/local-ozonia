<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
<?php include('includes/common-head.php') ?>		
		<title>Ozonia | UV Solutions</title>
		<script type="text/javascript" src="scripts/jquery.roundaboutv2.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			$('.carousel ul').roundabout({
				//debug: true,
				reflect:true,
				shape: 'square',
				minScale: .4,
				btnPrev: '#carPrev',
				btnNext: '#carNext',
				btnNextCallback: function(){showContent('next')},
				btnPrevCallback: function(){showContent('prev')}
			});
			
			//set defaults
			$('#carPrev, #carNext').click(function(e){
				e.preventDefault();
			});								
			
			//$('.cc-block').not(':first-child').hide();
			$('.cc-block').hide();
			
			// Get total sections
			var sectionTotal = 0;
			$('.carousel li a').each(function(index){
				sectionTotal++;
				$(this).click(function(){
					goToContent(index);
				});		
			});
						
			//Track current section
			var curSection = 0;			
			
			//Show content based on NextPrev buttons or solutions nav
					
			function showContent(nextOrPrev){				
					$('.cc-block').eq(curSection).fadeOut(300, function(){					
						if(nextOrPrev == 'next'){
							if(curSection < sectionTotal-1){
								curSection++;							
								$('.cc-block').eq(curSection).fadeIn();
							}else{
								curSection = 0;	
								$('.cc-block').eq(curSection).fadeIn();
							}
						}
						else if(nextOrPrev == 'prev'){
							if(curSection > 0){
								curSection--;						
								$('.cc-block').eq(curSection).fadeIn();	
							}else{						
								curSection = sectionTotal-1;													
								$('.cc-block').eq(curSection).fadeIn();	
							}
	
						}
	
					});
			};				
			
			function goToContent(index){
				$('.cc-block').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block').eq(curSection).fadeIn();	
				});
			};
			
			// Navigate to content section when click on carousel images
			$('.carousel ul li a').click(function(e){
					e.preventDefault();
					thisIndex = $('.carousel ul li a').index(this);
					goToContent(thisIndex);
			});	
						
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					//$('.carousel ul').roundabout_animateToChild(hash);					
					$('.carousel ul').roundabout('animateToChild',hash);			
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			var url = $.url();
			//alert(url.attr('file'));
			
			$('.product-side-nav li a').each(function(){
				$(this).attr('rel',$(this).attr('href'));
			});
			
			$('.easy-select-box ul li a, .product-side-nav li a').click(function() {
				if($(this).attr('rel') != '') {					
					theHref = $(this).attr('rel');
					var relSplit = theHref.split('#');				
					if(url.attr('file') == relSplit[0]){
						location.replace(theHref);						
						location.reload();
					}else{ /*not this page*/
						window.open(theHref, '_self');
						
					}
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>

		
	</head>
	
	
	<body class="inner-page">
		<div class="wrapper whitebg round2 shadow1">
			<?php include('includes/header.php') ?>

			<div class="hero-inner clearfix">
				<div class="hero-content">

					<div class="carousel">
						<ul>
							<li><a href=""><img src="images/product/uv/uv.jpg" alt="uv" /></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-3x.jpg" alt="aquaray-3x"/></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-ho.jpg" alt="aquaray-ho"/></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-h2o.jpg" alt="aquaray-h20"/></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-lp.jpg" alt="aquaray-lp"/></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-slp.jpg" alt="aquaray-slp"/></a></li>
							<li><a href=""><img src="images/product/uv/aquaray-smp.jpg" alt="aquaray-smp"/></a></li>
						</ul>
					</div>
					<ul class="carousel-nav">
						<li><a href="#" id="carPrev">&laquo;</a></li>
						<li class="last"><a href="#" id="carNext">&raquo;</a></li>
					</ul>

				</div>	
				<?php include('includes/solutions-nav.php') ?>
			</div>

			<div class="pagecontent">			

				<h2 class="section-title">UV Products</h2>

				<div class="carousel-content clearfix">

					<div class="cc-block">
						<div class="left">
							<h3>Ultraviolet Solutions</h3>
							<p>Ultraviolet (UV) disinfection is environmentally safe and recognized as highly effective on a wide range of pathogens, including viruses. For the past 20 years, Ozonia has been providing UV disinfection systems to successfully to eliminate hazardous and environmentally unacceptable chemicals such as chlorine and other associated disinfection by-products. Today, Ozonia offers a complete range of UV products for municipal wastewater, municipal drinking water and industrial applications.</p>
																	
						</div>
					</div><!-- end cc block -->							

					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; 3X</h3>
							<p>The Aquaray&reg; 3X Vertical Lamp System offers a high amount of UV output within a reduced footprint while providing the degree of disinfection required for even the most stringent of effluent criteria, such as Reuse applications.</p>
							<p>The Aquaray&reg; 3X High Output Vertical Lamp Ultraviolet Disinfection System has been designed to provide disinfection for larger wastewater plants within a small footprint. The germicidal effect of the UV light inactivates most microorganisms such as bacteria, viruses and parasites, while eliminating the need for dangerous chemicals.</p>
							<ul>
								<li>Energy conservation: With a combination of variable-output electronic ballasts, highly efficient amalgam lamps and row-by-row lamp switching increments, the Aquaray&reg; 3X ensures energy conservation by dose pacing based onflow rate.</li>
								<li>Validated performance: The Aquaray&reg; 3X has been third party validated and completed strict bioassay testing.</li>
								<li>Easy maintenance: Due to the vertical design, the Aquaray&reg; 3X includes easy access to the UV lamps and quartz sleeves (no need to remove the UV module).</li>
								<li>Save space: To minimize the footprint, the Aquaray&reg; 3X utilizes Low Pressure High Output Amalgam lamps in a vertical design.</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/Aquaray3X_EU_Ozonia.pdf">Ozonia - Aquaray&reg; 3X (A4-English) PDF - 363.5 kb</a></li>
								<li><a href="media/pdf/Aquaray3X_US_ozonia.pdf">Ozonia - Aquaray&reg; 3X (US-English) PDF - 398.5 kb</a></li>
								<li><a href="media/pdf/Aquaray-3x_A4_UE-F.pdf">Ozonia - Aquaray&reg; 3X (A4-Fran&ccedil;ais) PDF - 1015.6 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li>Wastewater Disinfection</li>
								<li>Wastewater Reuse</li>
								<li>CSO (Combined Sewer Overflow)</li>
							</ul>			
						</div>
					</div><!-- end cc block -->							

					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; 40 HO</h3>
							<p>The Aquaray&reg; 40 HO (High Output) Vertical Lamp System offers powerful UV output within a reduced footprint while providing the degree of disinfection required for even the most stringent of effluent criteria, such as Wastewater Reuse applications.</p>
							<p>The Aquaray&reg; 40 HO Vertical Lamp Ultraviolet Disinfection System has been designed to provide disinfection for wastewater plants within a small footprint. The germicidal effect of the UV light inactivates most micro-organisms such as bacteria, viruses and parasites, while eliminating the need for dangerous chemicals.</p>
							<ul>
								<li>Easy maintenance: Due to the vertical design, the Aquaray&reg; 40 HO provides easy access to the UV lamps and quartz sleeves (no need to remove the UV module)</li>
								<li>Save space: To minimize the footprint, the Aquaray&reg; 40 HO utilizes Low Pressure High Output lamps in a vertical design</li>
								<li>Energy conservation: With a combination of efficient ballasts and row-by-row lamp switching increments, the Aquaray&reg; 40 HO ensures energy conservation by dose pacing based on flow rate signal and UV transmittance</li>
								<li>Validated performance: The Aquaray&reg; 40 HO has been third party validated and completed strict bioassay testing</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/Aquaray40HO_EU_Ozonia.pdf">Ozonia - Aquaray&reg; 40 HO (A4-English) PDF - 314.2 kb </a></li>
								<li><a href="media/pdf/Aquaray40HO_US_Ozonia.pdf">Ozonia - Aquaray&reg; 40 HO (US-English) PDF - 316.5 kb </a></li>
								<li><a href="media/pdf/Aquaray-40HO_A4_EU-F.pdf">Ozonia - Aquaray&reg; 40 HO (A4-Fran&ccedil;ais) PDF - 901.1 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li>Wastewater Disinfection</li>
								<li>Wastewater Reuse</li>
								<li>CSO (Combined Sewer Overflow)</li>
							</ul>		
						</div>
					</div><!-- end cc block -->							
					
					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; H2O</h3>
							<p>The Aquaray&reg; H2O is able to treat from 300 to 8600 m3/h (2 to 55 MGD). This reactor eliminates pathogens with a powerful dose of UV light delivered by strategically placed medium pressure lamps.</p>
							<p>The Aquaray&reg;H20 units have been designed to disinfect drinking water. The germicidal effect of the UV light inactivates most microorganisms such as bacteria, viruses and parasites. UV is known to be particularly efficient to inactivate Cryptosporidium Parvum and Giardia Lamblia.</p>
							<ul>
								<li>Optimized performance: The Aquaray&reg; H2O has been optimized with CFD modeling software to maximize UV dose and minimize head loss.</li>
								<li>Energy conservation: Due to the electronic variable output ballast, the total power can be adjusted based on the demand.</li>
								<li>Save space: To minimize the footprint, the Aquaray&reg; H2O uses Medium Pressure lamps with high power density.</li>
								<li>Validated performance: The Aquaray&reg; H2O has been third party validated and obtained DVGW certification upon completion of strict bioassay testing.</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/H2O-OZONIA-US.pdf">Ozonia - H2O (US-English) PDF - 451.6 kb</a></li>
								<li><a href="media/pdf/H2O-OZONIA-EU.pdf">Ozonia - H2O (A4-English) PDF - 368.1 kb</a></li>
								<li><a href="media/pdf/Aquaray-H2O_A4_EU-F.pdf">Ozonia - H2O (A4-Fran&ccedil;ais) PDF - 931.6 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li>Drinking Water Disinfection</li>
							</ul>		
						</div>
					</div><!-- end cc block -->	

					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; LP</h3>
							<p>The Aquaray&reg; LP range offers compact and high efficiency system for small water plant with a range of flow rates from 10 to 40 m3/h with exceptional reliability and ease of operation.</p>
							<p>The Aquaray&reg; LP units have been designed to disinfect potable or process water. The germicidal effect of the UV light inactivates most micro-organisms such as bacteria, viruses and parasits. UV is known to be particularly efficient to inactivate Cryptosporidium Parvum and Giardia Lamblia.</p>
							<ul>
								<li>High-efficiency low-pressure amalgam lamp</li>
								<li>Lamp life of 16,000 h</li>
								<li>Horizontal or vertical reactor mounting</li>
								<li>Easy to install in new or existing water plants</li>
								<li>Small size suits installations with limited room space</li>
								<li>User friendly operator interface microprocessor controlled</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/LP_EU_Ozonia.pdf">Ozonia - Aquaray&reg; LP (A4-English) PDF - 308.5 kb</a></li>
								<li><a href="media/pdf/LP_EU_Triogen.pdf">Triogen - Aquaray&reg; LP (A4-English) PDF - 311 kb</a></li>
								<li><a href="media/pdf/LP_US_Ozonia.pdf">Ozonia - Aquaray&reg; LP (US-English) PDF - 308.5 kb</a></li>
								<li><a href="media/pdf/Aquaray-LP_A4_EU-F.pdf">Ozonia - Aquaray&reg; LP (A4-Fran&ccedil;ais) PDF - 807.4 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li><a href="app.php#10">Drinking water</a></li>
								<li><a href="app.php#5">Process water</a></li>
								<li><a href="app.php#0">Aquaculture</a></li>
								<li><a href="app.php#2">Cooling tower</a></li>
							</ul>	
						</div>
					</div><!-- end cc block -->						

					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; SLP</h3>
							<p>The Aquaray&reg; SLP UV systems offer compact and high efficiency disinfection for small and medium application with a range of flowrates from 25 to 600 m3/h with exceptional reliability and ease of operation.</p>
							<p>The Aquaray&reg; SLP units have been designed to disinfect potable or process water. The germicidal effect of the UV light inactivates most micro-organisms such as bacteria, viruses and parasits. UV is known to be particularly efficient to inactivate Cryptosporidium Parvum and Giardia Lamblia.</p>
							<ul>
								<li>High efficiency reactor with in-line water inlet</li>
								<li>Designed under DVGW Standard</li>
								<li>Exceptional lamp life of 16,000 h</li>
								<li>User friendly operator interface microprocessor controlled</li>
								<li>Easy to install in new or existing water plants</li>
								<li>Reactor mounting horizontal or vertical</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/SLP-DW-PW_EU_Triogen.pdf">Triogen - SLP DW/PW (A4-English) PDF - 289.4 kb</a></li>
								<li><a href="media/pdf/SLP-DW-PW_EU_Ozonia.pdf">Ozonia - SLP DW/PW (A4-English) PDF - 288 kb   </a></li>
								<li><a href="media/pdf/SLP-DW-PW_US_Ozonia.pdf">Ozonia - SLP DW/PW (US-English) PDF - 330.1 kb </a></li>
								<li><a href="media/pdf/Aquaray-SLP_DW_PW_A4_EU-F.pdf">Ozonia - SLP DW/PW (A4-Fran&ccedil;ais) PDF - 882.8 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li><a href="app.php#10">Drinking water</a></li>
								<li><a href="app.php#5">Process water </a></li>
								<li><a href="app.php#0">Aquaculture	 </a></li>
								<li><a href="app.php#">Deozonation	 </a></li>
								<li><a href="app.php#">Toc Reduction </a></li>
								<li><a href="app.php#">Ballast water </a></li>
								<li><a href="app.php#2">Cooling tower </a></li>
								<li><a href="app.php#">Advanced oxidation</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->		
					
					<div class="cc-block">
						<div class="left">
							<h3>Aquaray&reg; SMP</h3>
							<p>The Aquaray&reg; SMP-DW/PW range offers compact and high efficiency system for small and medium water plant with a range of flow rates from 22 to 440 m3/h with exceptional reliability and ease of operation</p>
							<p>The Aquaray&reg; SMP-DW/PW units have been designed to disinfect potable or process water. The germicidal effect of the UV light inactivates most micro-organisms such as bacteria, viruses and parasits. UV is known to be particularly efficient to inactivate Cryptosporidium Parvum and Giardia Lamblia.</p>
							<p>The medium pressure lamps have an action on nucleic acid and proteins for microorganisms inactivation. The UV dose (UV intensity x contact time) defines the treatment efficiency which is provided by the unit. The effective dose applied depends on the UV transmittance of water to be treated as well as the proper hydraulic design of the unit.</p>
							<ul>
								<li>Polychromatic medium pressure lamps for highest germicidal efficiency</li>
								<li>Fewer lamps</li>
								<li>Easy to install in new or existing water plants</li>
								<li>User friendly operator interface microprocessor controlled</li>
								<li>Data logging for up to one year</li>
							</ul>
							<h4>Literature</h4>
							<ul>
								<li><a href="media/pdf/SMP-DW_EU_TRIOGEN.pdf">Triogen SMP-DW/PW (A4-English) PDF - 327.5 kb</a></li>
								<li><a href="media/pdf/SMP-DW_EU_OZONIA.pdf">Ozonia SMP-DW/PW (A4-English) PDF - 309.9 kb </a></li>
								<li><a href="media/pdf/SMP-DW_US_OZONIA.pdf">Ozonia SMP-DW/PW (US-English) PDF - 333.1 kb </a></li>
								<li><a href="media/pdf/Aquaray-SMP_DW_PW_A4_EU-F.pdf">Ozonia SMP-DW/PW (A4-Fran&ccedil;ais) PDF - 912.1 kb</a></li>
							</ul>
							<h4>Applications</h4>
							<ul>
								<li><a href="app.php#10">Drinking water</a></li>
								<li><a href="app.php#5">Process water</a></li>
								<li><a href="app.php#0">Aquaculture</a></li>
								<li><a href="app.php#">Deozonation</a></li>
								<li><a href="app.php#">Toc Reduction</a></li>
								<li><a href="app.php#">Ballast water</a></li>
								<li><a href="app.php#2">Cooling tower</a></li>
								<li><a href="app.php#">Advanced oxidation</a></li>
							</ul>
						</div>
					</div><!-- end cc block -->	

				<div class="right">
							<h4>UV Products:</h4>
							<ul class="product-side-nav">
								<li><a rel="" href="uv.php#1">Aquaray 3x</a></li>
								<li><a rel="" href="uv.php#2">Aquaray 40 HO</a></li>
								<li><a rel="" href="uv.php#3">Aquaray H2O</a></li>
								<li><a rel="" href="uv.php#4">Aquaray LP</a></li>
								<li><a rel="" href="uv.php#5">Aquaray SLP</a></li>
								<li><a rel="" href="uv.php#6">Aquaray SMP</a></li>									
							</ul>
							<h4>Product Range:</h4>
							<ul>
								<li><a href="media/pdf/EU_UV_RANGE.pdf">UV Range (A4-English)</a></li>
								<li><a href="media/pdf/US_UV_RANGE.pdf">UV Range (US-English)</a></li>
								<li><a href="media/pdf/Ozonia_UV_RANGE_Cn.pdf">UV Range (Chinese)</a></li>
								<li><a href="media/pdf/DESINFECTION-GAMME_UV_A4_EU-F.pdf">UV Range (Fran&ccedil;ais)</a></li>
							</ul>
				</div><!-- end right -->											
				</div><!-- end corousel content -->							


			</div><!-- end pagecontent -->				
		</div><!-- end content (wrapper) -->					

		<?php include('includes/footer.php') ?>
	</body>