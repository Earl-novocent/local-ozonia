<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>Ozonia</title>
<?php include('includes/common-head.html'); ?>	
		<script type="text/javascript" src="scripts/jquery.roundabout.js"></script>
		<script type="text/javascript" src="scripts/jquery.roundabout-shapes.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('.solution-list select').easySelectBox({speed: 100});
			
			$('.carousel ul').roundabout({
				//debug: true,
				shape: 'square',
				minScale: .6,
				btnPrev: '#carPrev',
				btnNext: '#carNext'
			});
			
			//set defaults
			$('#carPrev, #carNext').click(function(e){
				e.preventDefault();
			});								
			
			//$('.cc-block').not(':first-child').hide();
			$('.cc-block').hide();
			
			// Get total sections
			var sectionTotal = 0;
			$('.carousel li a').each(function(index){
				sectionTotal++;
				$(this).click(function(){
					goToContent(index);
				});		
			});
			
			
			//Track current section
			var curSection = 0;			
			
			//Show content based on NextPrev buttons or solutions nav
			
			$('#carNext').click(function(){
					showContent('next');
			});
			$('#carPrev').click(function(){
					showContent('prev');
			});				
			
			function showContent(nextOrPrev){				
				$('.cc-block').eq(curSection).fadeOut(300, function(){
					if(nextOrPrev == 'next'){
						if(curSection < sectionTotal-1){
							curSection++;
							$('.cc-block').eq(curSection).fadeIn();
						}else{
							curSection = 0;
							$('.cc-block').eq(curSection).fadeIn();
						}
					}
					else if(nextOrPrev == 'prev'){
						if(curSection > 0){
							curSection--;
							$('.cc-block').eq(curSection).fadeIn();						
						}else{
							curSection = sectionTotal-1;
							$('.cc-block').eq(curSection).fadeIn();	
						}

					}
					console.log(curSection);
				});
			};				
			
			function goToContent(index){
				$('.cc-block').eq(curSection).fadeOut(function(){
					curSection = index;
					$('.cc-block').eq(curSection).fadeIn();	
				});
			};
			
			
			//Check to see if a hash number is in the url -- Go to associated index
			function hashNav(){
				if(location.hash){
					var hash = location.hash.substring(1);
					$('.carousel ul').roundabout_animateToChild(hash);
					goToContent(hash);
				};
			};
			
			hashNav();
			
			//Solutions list navigation
			$('.easy-select-box ul li a').click(function() {
				if($(this).attr('rel') != '') {
					window.location.replace($(this).attr('rel'));
					window.location.reload();
				}
			});	
						
			$('.easy-select-box ul li:first-child').hide();
		});
		</script>
	</head>
	
	<body>
	
		<div class="wrapper">

<?php include('includes/header.html'); ?>		
	
			<div class="content round1 shadow1">
				<div class="inner-page-top">
					<div class="clearfix">
						<h1 class="logo"><img src="images/logo.png" alt="Ozonia" width="226" height="86" /></h1>
						<h2 class="logo-tag">a world leader in ozone and UV water treatment</h2>
						<?php include('includes/solutions-nav.html')  ?>
					</div>	
					<div class="carousel">
						<ul>
							<li><a href=""><img src="images/carousel/app_1.png" alt="app_1" /></a></li>
							<li><a href=""><img src="images/carousel/app_1.png" alt="app_1" /></a></li>
							<li><a href=""><img src="images/carousel/app_1.png" alt="app_1" /></a></li>
						
						</ul>
					</div>
					<ul class="carousel-nav">
						<li><a href="" id="carPrev">&laquo;</a></li>
						<li><a href="" id="carNext">&raquo;</a></li>
					</ul>
					<h2 class="section-title">Contact</h2>
				</div><!-- end innerpage top -->
			
			
				<div class="block">
				<h2>Your are in this country:</h2>
					
					<?php include('includes/geolocate.php'); ?>
				</div>
						
			</div><!-- end content -->					


			
<?php include('includes/footer.html'); ?>

		</div><!-- end wrapper -->
	
	</body>
</html>