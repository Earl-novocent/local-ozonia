<?php

$theIP = $_SERVER['REMOTE_ADDR'];
// Website url to open
$theURL = 'http://api.ipinfodb.com/v3/ip-country/?key=9d7e17b98ac1cf9ca58a85c8ba8a6ee71fbb7efeb9d2119e838b72bb76f36ac8&ip='.$theIP;

// Get that website's content
$handle = fopen($theURL, "r");

// If there is something, read and return
if ($handle) {
	while (!feof($handle)) {
	    $buffer = fgets($handle, 4096);
	    $data = explode(';',$buffer);
	    echo $data[4];
	}
	fclose($handle);
}
?>